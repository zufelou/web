/**
 * Created by Xavier on 14-5-4.
 */
$_lang = {
    '买入' : '买入',
    '卖出': '卖出'
};